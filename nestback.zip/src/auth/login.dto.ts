export interface LoginDTO {
    email: string;
    password: string;
  }