
export interface RegisterDTO  {
    email:string;
    password: string;
  }