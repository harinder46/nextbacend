// import * as mongoose from 'mongoose';

// export const databaseProviders = [
//     {
//       provide: 'DATABASE_CONNECTION',
//       useFactory: (): Promise<typeof mongoose> =>
//         mongoose.connect('mongodb+srv://harinder:harinder46@cluster0.gfjii.mongodb.net/productdatabase?retryWrites=true&w=majority'),
//     },
//   ];